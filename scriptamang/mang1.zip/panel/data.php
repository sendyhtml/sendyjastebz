<?php 
$nik = "WEB CAHYO SR II";
$sender = "admin@putragodd.com";
?>