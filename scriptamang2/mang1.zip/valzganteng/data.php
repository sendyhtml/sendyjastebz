<?php 
$nik = "PANEL BY RYSNESIA⚡";
$sender = "admin@rysnesia.co.id";
?>